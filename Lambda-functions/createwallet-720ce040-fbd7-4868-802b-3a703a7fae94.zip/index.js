"use strict";

var ethers = require('ethers'),
    wallet = require('ethers').Wallet;
	
exports.handler = async (event, context, callback) => {
    //JSON response of wallet address and data
    callback(null, wallet.createRandom());
};