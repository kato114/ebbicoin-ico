const ethers = require('ethers')

exports.handler = async (event, context, callback) => {
	const privateKey = event.queryStringParameters.key
	const toAddress = event.queryStringParameters.to
	const value = event.queryStringParameters.amount

	let provider = ethers.getDefaultProvider()
	let wallet = new ethers.Wallet(privateKey, provider)
	let code = await provider.getCode(toAddress)
	let gasPrice = await provider.getGasPrice()
	let txnbalance = value - (gasPrice.toNumber() * 40000) / Math.pow(10, 18)
	txnbalance = txnbalance.toString()

	if (code !== '0x') {
		throw new Error('Cannot sweep to a contract')
	}

	let sendTransactionPromise = await wallet
		.sendTransaction({
			gasLimit: 40000,
			gasPrice: gasPrice,
			to: toAddress,
			value: ethers.utils.parseEther(txnbalance),
		})
		.then(function (transactionHash) {
			callback(null, transactionHash)
		})
		//If error
		.catch((err) => {
			callback(null, err)
		})
}
