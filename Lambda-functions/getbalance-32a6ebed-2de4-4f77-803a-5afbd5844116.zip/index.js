'use strict'

const ethers = require('ethers')
let provider = ethers.getDefaultProvider()

exports.handler = async (event, context, callback) => {
	var address = event.queryStringParameters.address
	let balance = await provider.getBalance(address)
	
	return balance / Math.pow(10,18)
}
